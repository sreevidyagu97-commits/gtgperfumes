# GTG Perfumes Website

A pixel-perfect, responsive e-commerce website for GTG Perfumes built with HTML, CSS, and JavaScript.

## 🚀 Quick Start

### Option 1: Open Directly (Easiest)
Simply double-click `index.html` to open it in your default browser. No server needed!

### Option 2: Local Server (Recommended for Development)
If you have Python installed:
```bash
python -m http.server 8000
```
Then open http://localhost:8000 in your browser.

Or use the provided batch file:
```bash
start-server.bat
```

If you have PHP installed:
```bash
php -S localhost:8000
```

## 📁 Project Structure

```
gtgperfumes/
├── index.html          # Main HTML file
├── css/
│   └── style.css      # All styles and responsive design
├── js/
│   └── script.js      # Interactive functionality
├── images/            # All image assets
└── start-server.bat   # Quick server starter (Windows)
```

## ✨ Features

- ✅ Pixel-perfect design matching the Figma mockup
- ✅ Fully responsive (Desktop, Tablet, Mobile)
- ✅ Smooth animations and transitions
- ✅ Interactive elements (carousel, accordion, forms)
- ✅ Cross-browser compatible (Chrome, Firefox, Edge, Safari)
- ✅ Performance optimized
- ✅ Accessible and SEO-friendly

## 🎨 Design Elements

- **Color Scheme**: Green (#4CAF50), White, Light Blue
- **Typography**: System fonts for optimal performance
- **Animations**: Smooth fade-ins, floating effects, hover states

## 📱 Responsive Breakpoints

- **Desktop**: 1024px and above
- **Tablet**: 768px - 1024px
- **Mobile**: Below 768px

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Edge (latest)
- Safari (latest)

## 📝 Notes

- All images are referenced from the `images/` folder
- No build process or npm required
- Pure vanilla JavaScript (no frameworks)
- CSS with modern features and vendor prefixes for compatibility

## 🔧 Troubleshooting

If images don't load:
- Make sure all image files are in the `images/` folder
- Check that image filenames match exactly (case-sensitive)
- Try opening via a local server instead of file:// protocol

